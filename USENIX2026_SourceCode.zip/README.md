# DRL-attacker

This work is submitted to USENIX 2026, titled: Security Analysis of Deep Reinforcement Learning Based Traffic Signal Control Systems Under Cooperative Perception Environment
